cat .hokok
sleep 1
echo "getting information ..."
sleep 1
echo "getting information ..."
sleep 1
echo "getting information ..."
sleep 1
echo "getting information ..."
sleep 1
echo "getting information ..."
sleep 1
echo "getting information ..."
sleep 1
echo "getting information ..."
sleep 1
echo "getting information ..."
sleep 1
echo "getting information ..."
sleep 1
echo "YOUR OSTYPE IS : $OSTYPE"
echo "YOUR HOSTNAME IS : $HOSTNAME"
echo "YOUR HOSTTYPE IS : $HOSTTYPE"
