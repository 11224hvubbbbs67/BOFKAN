import os
os.system("cat .hokok")
print(" ")
print("scan")
i = input("ENTER IP OR URL : ")
os.system("nmap -v -A "+i)
