import os
os.system("cat .hokok")
print(" ")
####################
print("ddos ping6")
i = input("ENTER IP : ")
os.system("ping6 "+i)
