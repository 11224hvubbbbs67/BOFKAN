cd /
find
