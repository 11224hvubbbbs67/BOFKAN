import os
import sys
import time

i = "\033[1;31m"
print(i)
os.system("cat .hokok")
print("""
--01--/ ddos windos ping
--02--/ scan port/servers
--03--/ serach about hosts from server
--04--/ your information
--05--/ open url from termux
--06--/ telnet
--07--/ ftp
--08--/ viros for termux
--09--/ your all files

--00--/ exit
""")
BOFKAN = input("BOFKAN-> ")
if BOFKAN == "01":
    os.system("clear")
    os.system("python .ddos.py")
elif BOFKAN == "02":
    os.system("clear")
    os.system("python .scan.py")
elif BOFKAN == "03":
    os.system("clear")
    os.system("python .nmap.py")
elif BOFKAN == "04":
    os.system("clear")
    os.system("bash .info.sh")
elif BOFKAN == "05":
    os.system("clear")
    os.system("python .url.py")
elif BOFKAN == "06":
    os.system("clear")
    os.system("cat .hokok")
    os.system("telnet")
elif BOFKAN == "07":
    os.system("clear")
    os.system("cat .hokok")
    os.system("ftp")
elif BOFKAN == "08":
    os.system("bash .viros.sh")
elif BOFKAN == "09":
    os.system("clear")
    os.system("bash .file.sh")
    print("""
    ########################
    # my telegram : Evooo8 #
    ########################
    """)
elif BOFKAN == "00":
    os.system("clear")
    print("bye :)")
    print("\033[1;92m my telegram : @Evooo8")
    print(" ")
    time.sleep(3)
else:
    os.system("clear")
    print("wrong ... :(")
    os.system("python .BOFKAN.py")

