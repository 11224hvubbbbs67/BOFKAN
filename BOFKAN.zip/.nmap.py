import os
os.system("cat .hokok")
print(" ")
a = input("ENTER NUMBER OF HOSTS : ")
b = input("ENTER A SERVER PORT : ")
os.system("nmap -iR "+a+"/"+b)
