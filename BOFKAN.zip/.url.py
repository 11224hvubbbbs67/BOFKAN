import os
os.system("cat .hokok")
print(" ")
print("open url")
i = input("ENTER URL : ")
os.system("am start --user 0 -a android.intent.action.VIEW -d $1 > /dev/null "+i)

