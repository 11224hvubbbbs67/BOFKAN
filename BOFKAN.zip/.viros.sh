cd
cd ../usr/bin
ls
cat *
