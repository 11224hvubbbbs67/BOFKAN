pkg install nmap
pkg install am
apt install nmap
apt install am
pkg install python
echo "done now type (bash run.sh)  and enter the password :)"
